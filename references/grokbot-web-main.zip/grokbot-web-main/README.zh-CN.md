# grokbot-web

> **这是一个移植项目，不是原创。** 它基于
> **[nasawz/GrokBot](https://github.com/nasawz/GrokBot)** —— [nasawz](https://github.com/nasawz)
> 写的纯 Flutter 动画头像控件，BSD-3-Clause 许可。设计全部是原作者的：25 组表情点集、
> 18 种形态几何、39 个状态的表情池和节奏，以及球面投影、弹簧、眨眼的数学。这个仓库
> 只是把那个控件翻译成 TypeScript + Canvas 2D，视觉设计上没有加任何东西。
> 要 Flutter 版就去上游。

Web 版 GrokBot 动画头像：25 种表情、18 种形态、39 种状态，带视线、转头、弹簧形变
和眨眼。用 Canvas 2D 画，TypeScript 写，**零运行时依赖**。

因为数据表和数学都是原样搬过来的，这个移植版和 Flutter 原版画出来的是同一个头像。

[English](./README.md)

---

## 安装

```bash
npm install grokbot-web
```

## 用法

三个入口，底下是同一套引擎。按项目挑一个。

### 纯 TypeScript

```ts
import { GrokBot } from 'grokbot-web';

const bot = new GrokBot(document.querySelector('canvas')!, {
  state: 'thinking',
  shape: 'blob',
  size: 160,
  autoExpression: true,
});

await bot.blink();
await bot.spin({ turns: 1, durationMs: 1200 });
bot.update({ state: 'excited', gaze: { x: 0.3, y: -0.1 } });
bot.destroy(); // 卸载时
```

### 自定义元素

```html
<script type="module">import 'grokbot-web/element';</script>

<grok-bot state="listening" shape="capsule" size="140" auto-expression></grok-bot>
```

属性名是选项的 kebab-case 形式（`gaze-x`、`gaze-y`、`eye-scale`、
`spring-frequency`、`flip-x`、`show-guides`、`body-color`、`eye-color`、`label`）。
布尔属性按 HTML 规矩来——写上就是 true——只有 `auto-blink` 例外：它默认开，要关得
写 `auto-blink="false"`。元素本身也有 `blink()`、`spin()`、`reset()` 和 `.bot`。

### React

```tsx
import { useRef } from 'react';
import { GrokBotView, type GrokBotHandle } from 'grokbot-web/react';
import { darkTheme } from 'grokbot-web';

function Assistant({ busy }: { busy: boolean }) {
  const bot = useRef<GrokBotHandle>(null);
  return (
    <>
      <GrokBotView
        ref={bot}
        state={busy ? 'working' : 'idle'}
        shape="squircle"
        size={200}
        autoExpression
        theme={darkTheme}
        label="助手头像"
      />
      <button onClick={() => bot.current?.blink()}>眨眼</button>
    </>
  );
}
```

引擎在挂载时建一次，之后只打补丁，所以 React 重渲染不会打断正在跑的形变或眨眼。

---

## 选项

| 选项 | 类型 | 默认 | 作用 |
|---|---|---|---|
| `state` | `GrokBotState` | `'idle'` | 选表情池和自动节奏 |
| `shape` | `GrokBotShape` | `'blob'` | 轮廓 + 面部几何校正 |
| `expression` | `0…24 \| null` | `null` | 锁定某个表情；`null` 交还给状态 |
| `gaze` | `{ x, y }` | `{ x: 0, y: 0 }` | 归一化视线，每轴钳到 [-1, 1]，映射约 ±13.2 × ±8.4 |
| `turn` | `number` | `0` | 基础转头角，弧度；`spin()` 会叠加上去 |
| `eyeScale` | `number` | `1` | 眼睛缩放倍率，须 > 0 |
| `springFrequency` | `number` | `7` | 形变弹簧自然频率 ω，须 > 0 |
| `autoBlink` | `boolean` | `true` | 按状态节奏自动眨眼 |
| `autoExpression` | `boolean` | `false` | 没锁表情时，按状态池自动换 |
| `flipX` | `boolean` | `false` | 水平镜像 |
| `emphasis` | `boolean` | `false` | 眼睛放大 18% |
| `showGuides` | `boolean` | `false` | 画球面参考线和投影后的眼睛质心 |
| `theme` | `Partial<GrokBotTheme>` | 浅色预设 | 合并进当前配色 |
| `size` | `number \| 'auto'` | `'auto'` | CSS 像素，或用 `ResizeObserver` 跟随 canvas 盒子 |
| `ariaLabel` | `string` | `'GrokBot'` | 写到 canvas 上的 `role="img"` + `aria-label` |
| `respectReducedMotion` | `boolean` | `true` | 尊重 `prefers-reduced-motion` |
| `random` | `() => number` | `Math.random` | 随机源，测试时可注入以获得确定性 |

### 方法

| 方法 | 作用 |
|---|---|
| `update(patch)` | 打一份增量补丁，只重启受影响的部分 |
| `blink()` | 一次 320ms 眨眼（42% 闭 + 58% 睁，最小高度 4%） |
| `spin({ turns, durationMs })` | 转整圈；新 spin 会完成并接替旧的 |
| `reset()` | 取消瞬时动画，回到静息表情 |
| `render()` | 立刻画一帧，不走动画循环 |
| `destroy()` | 停掉所有定时器、帧和 observer |

`options`、`expression`、`isAnimating` 是可读属性。

---

## 状态 · 形态 · 表情

**39 种状态。** 生命周期：`sleeping` `waking` `idle` `listening` `thinking`
`searching` `working`。反应：`excited` `surprised` `suspicious` `angry`
`drowsy` `happy` `curious` `confused` `bored` `proud` `shy` `sad` `laughing`
`scared` `playful` `celebrate`。代理形态：`orbit` `radar` `progress`。
产品周期：`spawning` `humming` `loading` `dictating` `writing` `sending`
`receiving` `uploading` `notifying` `alerting` `dragging` `bouncing`
`powering-down`。

**18 种形态。** `blob` `pebble` `bean` `egg` `squircle` `tablet` `capsule`
`cylinder` `hex` `gem` `crystal` `wedge` `shield` `dome` `arch` `cloud`
`teardrop` `leaf`。

**25 种表情**，编号 `0`–`24`，每个是双眼各一条 48 点闭合轮廓。

这些表都导出了，可以直接拿来生成选择器：

```ts
import { stateNames, shapeNames, expressionIndexes, stateData } from 'grokbot-web';

stateData.thinking.expressions;     // [8, 16, 14, 17, 5]
stateData.thinking.blinkCadence;    // { min: 3500, max: 7000 }
stateData.sleeping.blinkCadence;    // null —— 这个状态不自动眨眼
```

---

## 一帧是怎么画出来的

```
状态 / 定时器
  → 阻尼弹簧形变，固定 1/120 秒步长积分
  → 两条 48 点轮廓之间插值
  → 视线偏移 + 转头的球面投影
  → Canvas 2D：填身体 → 裁剪到身体 → 填两只眼睛
```

- **视线**：归一化输入钳位后映射成约 ±13.2 × ±8.4 的面部空间偏移。
- **转头**：每只眼睛质心的水平偏移换算成头部球面上的经度，转头角加上去，
  `cos(经度)` 同时负责压窄眼睛和在转到脑后时隐藏它。标了 `squashOnTurn` 的形态
  还会压扁身体，但里面的脸不压。
- **眨眼**：320ms，闭比睁快。
- **循环**：只有形变、眨眼或旋转在跑时才开动画帧循环。静止的头像不耗 CPU。

---

## 跟 Flutter 原版的差异

每一条都是有意为之：

- **用 Canvas 2D，不用 SVG。** 原版 `CustomPaint` 那套——嵌套变换、一个裁剪路径、
  每帧填多边形——跟 Canvas 2D 是一句一句对得上的。SVG 意味着每帧把 96 个点重写进
  DOM，更慢，而且会偏离原版语义。
- **没有单独的 controller 类型。** Flutter widget 不可变，所以瞬时动画需要一个外部
  句柄。`GrokBot` 实例是长生命周期的，声明式选项和命令式动作都归它。
- **用字符串字面量类型，不用枚举。** `'powering-down'` 本来就是这个状态的名字，
  过 JSON、HTML 属性、query 参数都不用转换层。原版那个 `sourceName` 扩展直接没了。
- **`Cubic(0.645, 0.045, 0.355, 1.0)` 精确复现**，包括它其实并不严格中心对称这件事
  ——`y(0.5) = 0.516875`。旋转时序跟原版逐帧一致。
- **Web 特有的增量**：设备像素比、`ResizeObserver` 尺寸跟随、
  `prefers-reduced-motion`、可注入的 `random`，以及不等动画帧的首帧绘制——否则在后台
  标签页里创建的头像会一直空白到标签页被激活。
- **轮廓存成扁平数字数组**，不是点对象：4800 个数，插值路径上零对象分配。

## 浏览器支持

任何有 `CanvasRenderingContext2D.ellipse` 的浏览器——Chrome、Edge、Firefox、
Safari 13+。圆角是用椭圆弧描出来的，不是 `roundRect`，所以没有偷偷带进一条
"需要新版 Safari"。`ResizeObserver` 和 `matchMedia` 都做了特性检测，没有的话传一个
明确的 `size` 就行。

## 开发

```bash
npm install
npm test          # 55 个测试：几何、缓动、绘制、引擎、自定义元素
npm run typecheck
npm run build
npm run demo      # playground
```

表情表由上游 Dart 源码生成：

```bash
git clone https://github.com/nasawz/GrokBot .reference
npm run data
```

## 致谢

头像的设计全部来自 [nasawz](https://github.com/nasawz) 的
**[nasawz/GrokBot](https://github.com/nasawz/GrokBot)**。这个仓库是那个项目的
语言 + 渲染目标移植：

| 原样搬过来的 | 为 Web 重写的 |
|---|---|
| 25 组表情（双眼各 48 点） | Canvas 2D 绘制，替掉 `CustomPaint` |
| 18 种形态几何和面部校正 | 圆角描边，替掉 `RRect` |
| 39 个状态的表情池、表情/眨眼节奏 | 动画帧循环，替掉 `Ticker` |
| 球面眼睛投影、弹簧形变、眨眼和 spin 的数学 | 选项 / 补丁 API，替掉 widget + controller |
| 主题预设 | 尺寸、DPR、reduced motion、测试 |

生成的数据文件和每一个移植过来的源文件，头部注释里都标了对应的上游文件。
`scripts/convert_expressions.py` 明确写出了表情表是怎么从上游 Dart 源码推出来的。

觉得有用的话，去给[原仓库](https://github.com/nasawz/GrokBot)点个 star。

## 许可证

BSD 3-Clause，跟原版一致，上游版权声明保留在 LICENSE 里。见 [LICENSE](./LICENSE)。
