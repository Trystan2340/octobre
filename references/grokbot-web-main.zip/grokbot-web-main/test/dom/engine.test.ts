// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { GrokBot } from '../../src/engine';
import { stateData } from '../../src/data/states';
import { RecordingContext, stubCanvasContext } from '../recorder';

function contextOf(canvas: HTMLCanvasElement): RecordingContext {
  return (canvas as unknown as { __ctx: RecordingContext }).__ctx;
}

function makeCanvas(size = 200): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  Object.defineProperty(canvas, 'clientWidth', { value: size, configurable: true });
  Object.defineProperty(canvas, 'clientHeight', { value: size, configurable: true });
  document.body.append(canvas);
  return canvas;
}

/** Runs the animation loop forward by `ms` in ~16 ms animation frames. */
async function advance(ms: number): Promise<void> {
  const steps = Math.max(1, Math.round(ms / 16));
  for (let i = 0; i < steps; i += 1) {
    await vi.advanceTimersByTimeAsync(16);
  }
}

describe('GrokBot engine', () => {
  let bots: GrokBot[] = [];

  beforeEach(() => {
    stubCanvasContext();
    vi.useFakeTimers();
    bots = [];
  });

  afterEach(() => {
    for (const bot of bots) bot.destroy();
    vi.useRealTimers();
    document.body.innerHTML = '';
  });

  const create = (canvas: HTMLCanvasElement, init: ConstructorParameters<typeof GrokBot>[1] = {}) => {
    const bot = new GrokBot(canvas, { autoBlink: false, random: () => 0.5, ...init });
    bots.push(bot);
    return bot;
  };

  it('paints on construction and exposes image semantics', async () => {
    const canvas = makeCanvas();
    create(canvas, { ariaLabel: 'Assistant face' });
    await advance(32);
    expect(canvas.getAttribute('role')).toBe('img');
    expect(canvas.getAttribute('aria-label')).toBe('Assistant face');
    expect(contextOf(canvas).countFills()).toBeGreaterThan(0);
  });

  it('sizes the backing store by the device pixel ratio', async () => {
    const original = window.devicePixelRatio;
    Object.defineProperty(window, 'devicePixelRatio', { value: 2, configurable: true });
    const canvas = makeCanvas();
    create(canvas, { size: 120 });
    await advance(32);
    expect(canvas.width).toBe(240);
    expect(canvas.height).toBe(240);
    expect(canvas.style.width).toBe('120px');
    Object.defineProperty(window, 'devicePixelRatio', { value: original, configurable: true });
  });

  it('tracks the element box when the size is auto', async () => {
    const canvas = makeCanvas(150);
    create(canvas, { size: 'auto' });
    await advance(32);
    expect(canvas.width).toBe(150);
  });

  it('starts on the state resting expression and honours a pinned one', () => {
    const idle = create(makeCanvas());
    expect(idle.expression).toBe(stateData.idle.expressions[0]);
    const pinned = create(makeCanvas(), { state: 'thinking', expression: 12 });
    expect(pinned.expression).toBe(12);
  });

  it('morphs to the new state resting expression and settles', async () => {
    const bot = create(makeCanvas(), { state: 'idle' });
    bot.update({ state: 'angry' });
    expect(bot.expression).toBe(stateData.angry.expressions[0]);
    expect(bot.isAnimating).toBe(true);
    // Critically damped at omega = 7: displacement settles by ~1.5 s but the
    // velocity term needs ~2 s to drop under the 1e-3 epsilon.
    await advance(2500);
    expect(bot.isAnimating).toBe(false);
  });

  it('resolves a blink after 320 ms', async () => {
    const bot = create(makeCanvas());
    let done = false;
    void bot.blink().then(() => {
      done = true;
    });
    await advance(160);
    expect(done).toBe(false);
    await advance(400);
    expect(done).toBe(true);
    expect(bot.isAnimating).toBe(false);
  });

  it('lets a new spin replace the one in flight', async () => {
    const bot = create(makeCanvas());
    let firstDone = false;
    void bot.spin({ durationMs: 4000 }).then(() => {
      firstDone = true;
    });
    await advance(64);
    const second = bot.spin({ turns: -1, durationMs: 200 });
    await advance(32);
    expect(firstDone).toBe(true);
    await advance(400);
    await second;
    expect(bot.isAnimating).toBe(false);
  });

  it('rejects a non-positive spin duration and ignores a zero-turn spin', async () => {
    const bot = create(makeCanvas());
    expect(() => bot.spin({ durationMs: 0 })).toThrow(RangeError);
    await expect(bot.spin({ turns: 0 })).resolves.toBeUndefined();
  });

  it('snaps back to the resting face on reset', async () => {
    const bot = create(makeCanvas(), { state: 'thinking' });
    void bot.blink();
    bot.update({ expression: 20 });
    bot.reset();
    expect(bot.isAnimating).toBe(false);
    expect(bot.expression).toBe(20);
    bot.update({ expression: null });
    bot.reset();
    expect(bot.expression).toBe(stateData.thinking.expressions[0]);
  });

  it('blinks automatically on the state cadence and stops when turned off', async () => {
    const canvas = makeCanvas();
    // random() === 0 picks the shortest cadence, 6000 ms for idle.
    const bot = create(canvas, { autoBlink: true, random: () => 0 });
    expect(bot.isAnimating).toBe(false);
    await vi.advanceTimersByTimeAsync(6000);
    await advance(32);
    expect(bot.isAnimating).toBe(true);
    await advance(400);

    bot.update({ autoBlink: false });
    await vi.advanceTimersByTimeAsync(20000);
    await advance(32);
    expect(bot.isAnimating).toBe(false);
  });

  it('never schedules a blink for a state that has no blink cadence', async () => {
    const bot = create(makeCanvas(), { state: 'sleeping', autoBlink: true });
    await vi.advanceTimersByTimeAsync(60000);
    await advance(32);
    expect(bot.isAnimating).toBe(false);
  });

  it('rotates through the pool while autoExpression is on', async () => {
    const bot = create(makeCanvas(), { state: 'searching', autoExpression: true, random: () => 0 });
    const first = bot.expression;
    await vi.advanceTimersByTimeAsync(1000);
    await advance(32);
    expect(bot.expression).not.toBe(first);
  });

  it('leaves a pinned expression alone even with autoExpression on', async () => {
    const bot = create(makeCanvas(), { state: 'searching', autoExpression: true, expression: 7, random: () => 0 });
    await vi.advanceTimersByTimeAsync(20000);
    expect(bot.expression).toBe(7);
  });

  it('validates its options', () => {
    const canvas = makeCanvas();
    expect(() => create(canvas, { eyeScale: 0 })).toThrow(RangeError);
    expect(() => create(canvas, { springFrequency: -1 })).toThrow(RangeError);
    expect(() => create(canvas, { size: 0 })).toThrow(RangeError);
    // @ts-expect-error deliberately invalid state
    expect(() => create(canvas, { state: 'nope' })).toThrow(RangeError);
    // @ts-expect-error deliberately invalid shape
    expect(() => create(canvas, { shape: 'nope' })).toThrow(RangeError);
  });

  it('merges partial themes onto the current palette', () => {
    const bot = create(makeCanvas(), { theme: { bodyColor: '#123456' } });
    expect(bot.options.theme.bodyColor).toBe('#123456');
    expect(bot.options.theme.eyeColor).toBe('#fffdf7');
    bot.update({ theme: { eyeColor: '#000000' } });
    expect(bot.options.theme.bodyColor).toBe('#123456');
    expect(bot.options.theme.eyeColor).toBe('#000000');
  });

  it('stops every timer and frame on destroy', async () => {
    const canvas = makeCanvas();
    const bot = new GrokBot(canvas, { autoBlink: true, autoExpression: true, random: () => 0 });
    await advance(32);
    const before = contextOf(canvas).calls.length;
    bot.destroy();
    await vi.advanceTimersByTimeAsync(30000);
    expect(contextOf(canvas).calls.length).toBe(before);
    // Post-destroy calls are inert rather than throwing.
    await expect(bot.blink()).resolves.toBeUndefined();
    bot.update({ state: 'happy' });
    bot.reset();
  });

  it('paints synchronously when the document is hidden', () => {
    const visibility = Object.getOwnPropertyDescriptor(Document.prototype, 'hidden');
    Object.defineProperty(document, 'hidden', { value: true, configurable: true });

    const canvas = makeCanvas();
    create(canvas);
    // No animation frame has run, yet the canvas is already drawn: a background
    // tab must not show an empty avatar when it is brought forward.
    expect(contextOf(canvas).countFills()).toBeGreaterThan(0);
    expect(canvas.width).toBe(200);

    if (visibility) Object.defineProperty(Document.prototype, 'hidden', visibility);
    else Reflect.deleteProperty(document, 'hidden');
  });

  it('holds still when the user asks for reduced motion', async () => {
    const original = window.matchMedia;
    window.matchMedia = ((query: string) => ({
      matches: query.includes('reduce'),
      media: query,
      addEventListener: () => {},
      removeEventListener: () => {},
    })) as unknown as typeof window.matchMedia;

    const bot = create(makeCanvas(), { state: 'searching', autoBlink: true, autoExpression: true, random: () => 0 });
    const first = bot.expression;
    await vi.advanceTimersByTimeAsync(30000);
    await advance(32);
    expect(bot.isAnimating).toBe(false);
    expect(bot.expression).toBe(first);

    bot.update({ state: 'angry' });
    expect(bot.isAnimating).toBe(false);

    window.matchMedia = original;
  });
});
