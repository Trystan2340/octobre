// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { stubCanvasContext } from '../recorder';

describe('<grok-bot>', () => {
  beforeEach(async () => {
    stubCanvasContext();
    vi.useFakeTimers();
    await import('../../src/element');
  });

  afterEach(() => {
    vi.useRealTimers();
    document.body.innerHTML = '';
  });

  const mount = async (html: string) => {
    document.body.innerHTML = html;
    const element = document.body.firstElementChild as HTMLElement & {
      bot: import('../../src/engine').GrokBot | null;
      blink(): Promise<void>;
      reset(): void;
    };
    await vi.advanceTimersByTimeAsync(32);
    return element;
  };

  it('registers the custom element', () => {
    expect(customElements.get('grok-bot')).toBeDefined();
  });

  it('reads options from attributes', async () => {
    const element = await mount(
      '<grok-bot state="thinking" shape="capsule" turn="0.4" gaze-x="0.5" size="140" label="Bot"></grok-bot>',
    );
    expect(element.bot?.options.state).toBe('thinking');
    expect(element.bot?.options.shape).toBe('capsule');
    expect(element.bot?.options.turn).toBe(0.4);
    expect(element.bot?.options.gaze.x).toBe(0.5);
    expect(element.bot?.options.size).toBe(140);
    expect(element.bot?.options.ariaLabel).toBe('Bot');
  });

  it('treats auto-blink as on unless explicitly disabled', async () => {
    expect((await mount('<grok-bot></grok-bot>')).bot?.options.autoBlink).toBe(true);
    expect((await mount('<grok-bot auto-blink="false"></grok-bot>')).bot?.options.autoBlink).toBe(false);
    expect((await mount('<grok-bot auto-expression></grok-bot>')).bot?.options.autoExpression).toBe(true);
  });

  it('falls back to defaults for unknown enum values', async () => {
    const element = await mount('<grok-bot state="nope" shape="nope"></grok-bot>');
    expect(element.bot?.options.state).toBe('idle');
    expect(element.bot?.options.shape).toBe('blob');
  });

  it('applies attribute changes to the live engine', async () => {
    const element = await mount('<grok-bot state="idle"></grok-bot>');
    element.setAttribute('state', 'angry');
    expect(element.bot?.options.state).toBe('angry');
    element.setAttribute('body-color', '#ff0000');
    expect(element.bot?.options.theme.bodyColor).toBe('#ff0000');
  });

  it('tears the engine down when removed from the document', async () => {
    const element = await mount('<grok-bot></grok-bot>');
    expect(element.bot).not.toBeNull();
    element.remove();
    expect(element.bot).toBeNull();
  });
});
