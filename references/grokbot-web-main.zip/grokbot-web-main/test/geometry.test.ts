import { describe, expect, it } from 'vitest';
import {
  FACE_CENTER,
  bodyBoxFor,
  clamp,
  mapNormalizedGaze,
  parseBorderRadius,
  projectEye,
  ringCentroid,
} from '../src/geometry';
import { shapeData, shapeNames } from '../src/data/shapes';

describe('geometry', () => {
  it('clamps and maps normalized gaze to canvas units', () => {
    expect(mapNormalizedGaze({ x: 1, y: -1 })).toEqual({ x: 13.2, y: -8.4 });
    expect(mapNormalizedGaze({ x: 4, y: -3 })).toEqual({ x: 13.2, y: -8.4 });
    expect(mapNormalizedGaze({ x: 0, y: 0 })).toEqual({ x: 0, y: 0 });
  });

  it('averages every point of a ring', () => {
    expect(ringCentroid([0, 0, 4, 2])).toEqual({ x: 2, y: 1 });
  });

  it('clamps values on both sides', () => {
    expect(clamp(5, 0, 1)).toBe(1);
    expect(clamp(-5, 0, 1)).toBe(0);
    expect(clamp(0.25, 0, 1)).toBe(0.25);
  });

  it('follows the sphere and hides its back side', () => {
    const origin = { x: FACE_CENTER, y: FACE_CENTER };
    const front = projectEye({
      centroid: origin,
      origin,
      radius: 105,
      turn: 0,
      gaze: { x: 0, y: 0 },
      scale: 1,
      blinkScale: 1,
    });
    expect(front.center).toEqual(origin);
    expect(front.scaleX).toBe(1);
    expect(front.visible).toBe(true);

    const back = projectEye({
      centroid: origin,
      origin,
      radius: 105,
      turn: Math.PI,
      gaze: { x: 0, y: 0 },
      scale: 1,
      blinkScale: 1,
    });
    expect(back.visible).toBe(false);
    expect(back.scaleX).toBe(0.02);
  });

  it('narrows an off-center eye as the head turns away from it', () => {
    const origin = { x: FACE_CENTER, y: FACE_CENTER };
    const centroid = { x: FACE_CENTER + 40, y: FACE_CENTER };
    const rest = projectEye({ centroid, origin, radius: 105, turn: 0, gaze: { x: 0, y: 0 }, scale: 1, blinkScale: 1 });
    const turned = projectEye({ centroid, origin, radius: 105, turn: 0.9, gaze: { x: 0, y: 0 }, scale: 1, blinkScale: 1 });
    expect(rest.scaleX).toBeCloseTo(1, 10);
    expect(turned.scaleX).toBeLessThan(rest.scaleX);
    expect(turned.center.x).toBeGreaterThan(rest.center.x);
  });

  it('preserves the CSS elliptical radius syntax', () => {
    const radii = parseBorderRadius('50% / 32%', 100, 200);
    expect(radii).toHaveLength(4);
    expect(radii[0].x).toBe(50);
    expect(radii[0].y).toBe(64);
  });

  it('expands the 1, 2, 3 and 4 value radius shorthands', () => {
    expect(parseBorderRadius('10', 100, 100).map((r) => r.x)).toEqual([10, 10, 10, 10]);
    expect(parseBorderRadius('10 20', 100, 100).map((r) => r.x)).toEqual([10, 20, 10, 20]);
    expect(parseBorderRadius('10 20 30', 100, 100).map((r) => r.x)).toEqual([10, 20, 30, 20]);
    expect(parseBorderRadius('10 20 30 40', 100, 100).map((r) => r.x)).toEqual([10, 20, 30, 40]);
  });

  it('scales overlapping radii down to fit the box', () => {
    const radii = parseBorderRadius('80 80 0 0', 100, 100);
    expect(radii[0].x + radii[1].x).toBeCloseTo(100, 10);
  });

  it('produces a finite, non-empty body box for every shape', () => {
    for (const name of shapeNames) {
      const box = bodyBoxFor(shapeData[name]);
      expect(Number.isFinite(box.left), name).toBe(true);
      expect(Number.isFinite(box.top), name).toBe(true);
      expect(box.width, name).toBeGreaterThan(0);
      expect(box.height, name).toBeGreaterThan(0);
      for (const radius of box.radii) {
        expect(Number.isFinite(radius.x), name).toBe(true);
        expect(Number.isFinite(radius.y), name).toBe(true);
      }
    }
  });
});
