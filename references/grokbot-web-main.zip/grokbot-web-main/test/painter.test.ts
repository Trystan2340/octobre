import { describe, expect, it } from 'vitest';
import { expressionRings } from '../src/data/expressions';
import { shapeData } from '../src/data/shapes';
import { paintGrokBot, traceRoundRect, type PaintFrame } from '../src/painter';
import { lightTheme } from '../src/theme';
import { RecordingContext } from './recorder';

function frame(patch: Partial<PaintFrame> = {}): PaintFrame {
  return {
    rings: expressionRings[0],
    shape: shapeData.blob,
    gaze: { x: 0, y: 0 },
    turn: 0,
    eyeScale: 1,
    blinkScale: 1,
    flipX: false,
    emphasis: false,
    showGuides: false,
    theme: lightTheme,
    ...patch,
  };
}

describe('paintGrokBot', () => {
  it('fills the body once and each eye once', () => {
    const ctx = new RecordingContext();
    paintGrokBot(ctx, frame(), 200, 200);
    expect(ctx.countFills(`fill:${lightTheme.bodyColor}`)).toBe(1);
    expect(ctx.countFills(`fill:${lightTheme.eyeColor}`)).toBe(2);
    expect(ctx.count('clip')).toBe(1);
  });

  it('balances every save with a restore', () => {
    const ctx = new RecordingContext();
    paintGrokBot(ctx, frame({ showGuides: true, flipX: true }), 200, 200);
    let depth = 0;
    for (const op of ctx.ops()) {
      if (op === 'save') depth += 1;
      if (op === 'restore') depth -= 1;
      expect(depth).toBeGreaterThanOrEqual(0);
    }
    expect(depth).toBe(0);
  });

  it('drops eyes that have rotated behind the head', () => {
    const ctx = new RecordingContext();
    paintGrokBot(ctx, frame({ turn: Math.PI }), 200, 200);
    expect(ctx.countFills(`fill:${lightTheme.eyeColor}`)).toBe(0);
    expect(ctx.countFills(`fill:${lightTheme.bodyColor}`)).toBe(1);
  });

  it('centers the square view box inside a wide canvas', () => {
    const ctx = new RecordingContext();
    paintGrokBot(ctx, frame(), 400, 200);
    const first = ctx.calls.find((call) => call.op === 'translate');
    expect(first?.args).toEqual([100, 0]);
  });

  it('scales the view box to the shortest side', () => {
    const ctx = new RecordingContext();
    paintGrokBot(ctx, frame(), 259, 259);
    const scale = ctx.calls.find((call) => call.op === 'scale');
    expect(scale?.args).toEqual([1, 1]);
  });

  it('squashes only the shapes that opt in', () => {
    const squash = new RecordingContext();
    paintGrokBot(squash, frame({ shape: shapeData.bean, turn: 0.8 }), 200, 200);
    const squashScales = squash.calls.filter((call) => call.op === 'scale').map((call) => call.args[0]);
    expect(squashScales).toContain(Math.max(Math.cos(0.8), 0.55));

    const rigid = new RecordingContext();
    paintGrokBot(rigid, frame({ shape: shapeData.blob, turn: 0.8 }), 200, 200);
    const rigidScales = rigid.calls.filter((call) => call.op === 'scale').map((call) => call.args[0]);
    expect(rigidScales).not.toContain(Math.max(Math.cos(0.8), 0.55));
  });

  it('mirrors the whole avatar when flipped', () => {
    const ctx = new RecordingContext();
    paintGrokBot(ctx, frame({ flipX: true }), 200, 200);
    const scales = ctx.calls.filter((call) => call.op === 'scale').map((call) => call.args);
    expect(scales).toContainEqual([-1, 1]);
  });

  it('adds the guide stroke and centroid markers only when asked', () => {
    const plain = new RecordingContext();
    paintGrokBot(plain, frame(), 200, 200);
    expect(plain.countFills('stroke:')).toBe(0);
    expect(plain.count('arc')).toBe(0);

    const guided = new RecordingContext();
    paintGrokBot(guided, frame({ showGuides: true }), 200, 200);
    expect(guided.countFills(`stroke:${lightTheme.guideColor}`)).toBe(1);
    expect(guided.count('arc')).toBe(2);
  });

  it('shifts the eyes with gaze', () => {
    const rest = new RecordingContext();
    paintGrokBot(rest, frame(), 200, 200);
    const moved = new RecordingContext();
    paintGrokBot(moved, frame({ gaze: { x: 1, y: 0 } }), 200, 200);
    const eyeTranslate = (ctx: RecordingContext) =>
      ctx.calls.filter((call) => call.op === 'translate').at(-2)?.args[0] ?? 0;
    expect(eyeTranslate(moved)).toBeCloseTo(eyeTranslate(rest) + 13.2, 6);
  });

  it('emits every point of both 48-point rings', () => {
    const ctx = new RecordingContext();
    paintGrokBot(ctx, frame(), 200, 200);
    // Two body traces (one to fill, one to clip) emit 1 moveTo + 4 lineTo each;
    // the corners are ellipse arcs. Then 48 points per eye.
    const polygonPoints = ctx.polygonPoints().length;
    expect(polygonPoints).toBe(5 + 5 + 48 + 48);
  });

  it('renders every shape without producing a non-finite coordinate', () => {
    for (const [name, shape] of Object.entries(shapeData)) {
      const ctx = new RecordingContext();
      paintGrokBot(ctx, frame({ shape, turn: 0.5, gaze: { x: 0.5, y: -0.5 } }), 160, 160);
      const bad = ctx.calls.find((call) => call.args.some((value) => !Number.isFinite(value)));
      expect(bad, `${name} produced ${JSON.stringify(bad)}`).toBeUndefined();
    }
  });
});

describe('traceRoundRect', () => {
  it('emits four arcs and closes the path', () => {
    const ctx = new RecordingContext();
    traceRoundRect(ctx, 0, 0, 100, 50, [
      { x: 10, y: 5 },
      { x: 10, y: 5 },
      { x: 10, y: 5 },
      { x: 10, y: 5 },
    ]);
    expect(ctx.count('ellipse')).toBe(4);
    expect(ctx.count('closePath')).toBe(1);
    expect(ctx.calls[0].op).toBe('beginPath');
  });

  it('degenerates to a plain rectangle at zero radius', () => {
    const ctx = new RecordingContext();
    const zero = [0, 1, 2, 3].map(() => ({ x: 0, y: 0 }));
    traceRoundRect(ctx, 5, 5, 20, 10, zero);
    expect(ctx.polygonPoints()).toEqual([
      [5, 5],
      [25, 5],
      [25, 15],
      [5, 15],
      [5, 5],
    ]);
  });
});
