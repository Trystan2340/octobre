import type { Canvas2DLike } from '../src/painter';

export interface RecordedCall {
  op: string;
  args: number[];
}

/**
 * A minimal recording stand-in for `CanvasRenderingContext2D`.
 *
 * Using it instead of `node-canvas` keeps the test suite dependency-free and
 * lets assertions read the actual draw commands rather than pixels.
 */
export class RecordingContext implements Canvas2DLike {
  readonly calls: RecordedCall[] = [];
  fillStyle: string | CanvasGradient | CanvasPattern = '#000';
  strokeStyle: string | CanvasGradient | CanvasPattern = '#000';
  lineWidth = 1;

  #record(op: string, ...args: number[]): void {
    this.calls.push({ op, args });
  }

  save(): void { this.#record('save'); }
  restore(): void { this.#record('restore'); }
  translate(x: number, y: number): void { this.#record('translate', x, y); }
  scale(x: number, y: number): void { this.#record('scale', x, y); }
  setTransform(a: number, b: number, c: number, d: number, e: number, f: number): void {
    this.#record('setTransform', a, b, c, d, e, f);
  }
  beginPath(): void { this.#record('beginPath'); }
  moveTo(x: number, y: number): void { this.#record('moveTo', x, y); }
  lineTo(x: number, y: number): void { this.#record('lineTo', x, y); }
  closePath(): void { this.#record('closePath'); }
  ellipse(x: number, y: number, rx: number, ry: number, rotation: number, start: number, end: number): void {
    this.#record('ellipse', x, y, rx, ry, rotation, start, end);
  }
  arc(x: number, y: number, radius: number, start: number, end: number): void {
    this.#record('arc', x, y, radius, start, end);
  }
  fill(): void { this.calls.push({ op: `fill:${String(this.fillStyle)}`, args: [] }); }
  stroke(): void { this.calls.push({ op: `stroke:${String(this.strokeStyle)}`, args: [] }); }
  clip(): void { this.#record('clip'); }
  clearRect(x: number, y: number, width: number, height: number): void {
    this.#record('clearRect', x, y, width, height);
  }

  ops(): string[] {
    return this.calls.map((call) => call.op);
  }

  count(op: string): number {
    return this.calls.filter((call) => call.op === op).length;
  }

  countFills(prefix = 'fill:'): number {
    return this.calls.filter((call) => call.op.startsWith(prefix)).length;
  }

  /** Every point handed to `moveTo` / `lineTo`, in order. */
  polygonPoints(): Array<[number, number]> {
    return this.calls
      .filter((call) => call.op === 'moveTo' || call.op === 'lineTo')
      .map((call) => [call.args[0], call.args[1]] as [number, number]);
  }
}

/** Installs the recorder as the 2d context of every canvas in a jsdom document. */
export function stubCanvasContext(): RecordingContext[] {
  const created: RecordingContext[] = [];
  HTMLCanvasElement.prototype.getContext = function getContext(this: HTMLCanvasElement) {
    const existing = (this as unknown as { __ctx?: RecordingContext }).__ctx;
    if (existing) return existing as unknown as CanvasRenderingContext2D;
    const ctx = new RecordingContext();
    (this as unknown as { __ctx?: RecordingContext }).__ctx = ctx;
    created.push(ctx);
    return ctx as unknown as CanvasRenderingContext2D;
  } as unknown as HTMLCanvasElement['getContext'];
  return created;
}
