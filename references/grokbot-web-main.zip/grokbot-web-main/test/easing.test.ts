import { describe, expect, it } from 'vitest';
import { cubicBezier, easeInOutCubic } from '../src/easing';

describe('easing', () => {
  it('pins the endpoints', () => {
    expect(easeInOutCubic(0)).toBe(0);
    expect(easeInOutCubic(1)).toBe(1);
    expect(easeInOutCubic(-1)).toBe(0);
    expect(easeInOutCubic(2)).toBe(1);
  });

  it('matches the Flutter control points at the midpoint', () => {
    // Cubic(0.645, 0.045, 0.355, 1.0) is the CSS approximation Flutter ships.
    // It is not quite point-symmetric: y(0.5) = 0.516875, not 0.5. Asserting the
    // exact value is what pins this port to the original's timing.
    expect(easeInOutCubic(0.5)).toBeCloseTo(0.516875, 5);
  });

  it('rises monotonically', () => {
    let previous = -1;
    for (let i = 0; i <= 100; i += 1) {
      const value = easeInOutCubic(i / 100);
      expect(value).toBeGreaterThanOrEqual(previous);
      previous = value;
    }
  });

  it('reduces to the identity for a linear control polygon', () => {
    const linear = cubicBezier(1 / 3, 1 / 3, 2 / 3, 2 / 3);
    for (const t of [0.2, 0.5, 0.8]) {
      expect(linear(t)).toBeCloseTo(t, 4);
    }
  });
});
