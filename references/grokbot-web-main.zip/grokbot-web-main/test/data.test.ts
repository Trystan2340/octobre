import { describe, expect, it } from 'vitest';
import { EXPRESSION_COUNT, RING_POINTS, expressionRings } from '../src/data/expressions';
import { shapeData, shapeNames } from '../src/data/shapes';
import { stateData, stateNames } from '../src/data/states';

describe('expression data', () => {
  it('contains 25 well-formed two-eye expressions', () => {
    expect(expressionRings).toHaveLength(EXPRESSION_COUNT);
    for (const [index, expression] of expressionRings.entries()) {
      expect(expression, `expression ${index}`).toHaveLength(2);
      for (const eye of expression) {
        expect(eye).toHaveLength(RING_POINTS * 2);
        expect(eye.every(Number.isFinite)).toBe(true);
      }
    }
  });

  it('keeps every point inside the face coordinate space', () => {
    const values = expressionRings.flatMap((expression) => expression.flatMap((eye) => [...eye]));
    expect(Math.min(...values)).toBeGreaterThan(0);
    expect(Math.max(...values)).toBeLessThan(228.541);
  });
});

describe('state data', () => {
  it('covers 39 states with valid pools and cadences', () => {
    expect(stateNames).toHaveLength(39);
    for (const name of stateNames) {
      const data = stateData[name];
      expect(data.expressions.length, name).toBeGreaterThan(0);
      for (const expression of data.expressions) {
        expect(expression, name).toBeGreaterThanOrEqual(0);
        expect(expression, name).toBeLessThan(EXPRESSION_COUNT);
      }
      expect(data.expressionCadence.max, name).toBeGreaterThanOrEqual(data.expressionCadence.min);
      if (data.blinkCadence) {
        expect(data.blinkCadence.max, name).toBeGreaterThanOrEqual(data.blinkCadence.min);
      }
    }
  });

  it('names the kebab-case state directly', () => {
    expect(stateNames).toContain('powering-down');
    expect(stateData['powering-down'].expressions).toEqual([13, 22]);
  });
});

describe('shape data', () => {
  it('covers 18 shapes with positive geometry', () => {
    expect(shapeNames).toHaveLength(18);
    for (const name of shapeNames) {
      const data = shapeData[name];
      expect(data.faceScaleX, name).toBeGreaterThan(0);
      expect(data.faceScaleY, name).toBeGreaterThan(0);
      expect(data.eyeScale, name).toBeGreaterThan(0);
      expect(data.aspectX, name).toBeGreaterThan(0);
      expect(data.aspectY, name).toBeGreaterThan(0);
      expect(data.radius.length, name).toBeGreaterThan(0);
    }
  });
});
