import {
  GrokBot,
  type GrokBotInit,
  darkTheme,
  expressionIndexes,
  lightTheme,
  shapeNames,
  stateNames,
  type GrokBotExpression,
  type GrokBotShape,
  type GrokBotState,
  type GrokBotTheme,
} from '../src/index';

const $ = <T extends HTMLElement>(id: string): T => {
  const element = document.getElementById(id);
  if (!element) throw new Error(`missing #${id}`);
  return element as T;
};

const hero = new GrokBot($<HTMLCanvasElement>('hero'), {
  state: 'thinking',
  shape: 'blob',
  autoExpression: true,
  size: 'auto',
});

const gallery: GrokBot[] = [];
let dark = window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
let bodyOverride: string | null = null;
let eyeOverride: string | null = null;

/** Applies the same patch to the hero and to all 82 gallery avatars. */
function applyToAll(patch: GrokBotInit): void {
  hero.update(patch);
  for (const bot of gallery) bot.update(patch);
}

// ------------------------------------------------------------------ controls

function fillSelect(id: string, values: readonly string[], selected: string): void {
  const select = $<HTMLSelectElement>(id);
  select.innerHTML = values.map((value) => `<option value="${value}">${value}</option>`).join('');
  select.value = selected;
}

fillSelect('state', stateNames, 'thinking');
fillSelect('shape', shapeNames, 'blob');

const expressionSelect = $<HTMLSelectElement>('expression');
expressionSelect.innerHTML = [
  '<option value="auto">auto (state pool)</option>',
  ...expressionIndexes.map((index) => `<option value="${index}">${String(index).padStart(2, '0')}</option>`),
].join('');

$<HTMLSelectElement>('state').addEventListener('change', (event) => {
  hero.update({ state: (event.target as HTMLSelectElement).value as GrokBotState });
  updateSnippet();
});

$<HTMLSelectElement>('shape').addEventListener('change', (event) => {
  hero.update({ shape: (event.target as HTMLSelectElement).value as GrokBotShape });
  updateSnippet();
});

expressionSelect.addEventListener('change', (event) => {
  const raw = (event.target as HTMLSelectElement).value;
  hero.update({ expression: raw === 'auto' ? null : (Number(raw) as GrokBotExpression) });
  updateSnippet();
});

function bindRange(id: string, outputId: string, digits: number, apply: (value: number) => void): void {
  const input = $<HTMLInputElement>(id);
  const output = $<HTMLOutputElement>(outputId);
  const sync = () => {
    const value = Number(input.value);
    output.textContent = value.toFixed(digits);
    apply(value);
    updateSnippet();
  };
  input.addEventListener('input', sync);
  sync();
}

bindRange('turn', 'turn-value', 2, (value) => hero.update({ turn: value }));
bindRange('eye-scale', 'eye-scale-value', 2, (value) => hero.update({ eyeScale: value }));
bindRange('spring', 'spring-value', 1, (value) => hero.update({ springFrequency: value }));

function bindToggle(id: string, apply: (value: boolean) => void): void {
  const input = $<HTMLInputElement>(id);
  input.addEventListener('change', () => {
    apply(input.checked);
    updateSnippet();
  });
}

bindToggle('auto-blink', (value) => hero.update({ autoBlink: value }));
bindToggle('auto-expression', (value) => hero.update({ autoExpression: value }));
bindToggle('emphasis', (value) => hero.update({ emphasis: value }));
bindToggle('flip-x', (value) => hero.update({ flipX: value }));
bindToggle('show-guides', (value) => hero.update({ showGuides: value }));

$('blink').addEventListener('click', () => void hero.blink());
$('spin').addEventListener('click', () => void hero.spin());
$('spin-back').addEventListener('click', () => void hero.spin({ turns: -1, durationMs: 900 }));
$('reset').addEventListener('click', () => {
  hero.reset();
  $<HTMLInputElement>('turn').value = '0';
  $<HTMLOutputElement>('turn-value').textContent = '0.00';
  hero.update({ turn: 0 });
  updateSnippet();
});

// -------------------------------------------------------------- gaze pointer

const stage = $('stage');
stage.addEventListener('pointermove', (event) => {
  if (!$<HTMLInputElement>('follow-gaze').checked) return;
  const bounds = stage.getBoundingClientRect();
  hero.update({
    gaze: {
      x: ((event.clientX - bounds.left) / bounds.width) * 2 - 1,
      y: ((event.clientY - bounds.top) / bounds.height) * 2 - 1,
    },
  });
});

stage.addEventListener('pointerleave', () => {
  if (!$<HTMLInputElement>('follow-gaze').checked) return;
  hero.update({ gaze: { x: 0, y: 0 } });
});

// ------------------------------------------------------------------ galleries

interface CellSpec {
  label: string;
  init: GrokBotInit;
  onPick: () => void;
}

function buildGrid(id: string, specs: CellSpec[]): void {
  const grid = $(id);
  const fragment = document.createDocumentFragment();
  for (const spec of specs) {
    const cell = document.createElement('button');
    cell.type = 'button';
    cell.className = 'cell';
    const canvas = document.createElement('canvas');
    const label = document.createElement('span');
    label.textContent = spec.label;
    cell.append(canvas, label);
    cell.addEventListener('click', spec.onPick);
    fragment.append(cell);
    gallery.push(new GrokBot(canvas, { size: 72, ...spec.init }));
  }
  grid.append(fragment);
}

buildGrid(
  'shapes',
  shapeNames.map((shape) => ({
    label: shape,
    init: { shape, state: 'idle', autoBlink: true },
    onPick: () => {
      $<HTMLSelectElement>('shape').value = shape;
      hero.update({ shape });
      updateSnippet();
      scrollToTop();
    },
  })),
);

buildGrid(
  'expressions',
  expressionIndexes.map((expression) => ({
    label: String(expression).padStart(2, '0'),
    init: { expression, autoBlink: false },
    onPick: () => {
      expressionSelect.value = String(expression);
      hero.update({ expression });
      updateSnippet();
      scrollToTop();
    },
  })),
);

buildGrid(
  'states',
  stateNames.map((state) => ({
    label: state,
    init: { state, autoExpression: true, autoBlink: true },
    onPick: () => {
      $<HTMLSelectElement>('state').value = state;
      hero.update({ state });
      updateSnippet();
      scrollToTop();
    },
  })),
);

function scrollToTop(): void {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------------------------------------------------------------------- theme

const SWATCHES = [
  { name: 'GrokBot blue', color: '#5b7fe5' },
  { name: 'Ink', color: '#2f3330' },
  { name: 'Moss', color: '#3f8f5f' },
  { name: 'Clay', color: '#d2683f' },
  { name: 'Plum', color: '#7d4fa8' },
  { name: 'Teal', color: '#2b8b93' },
  { name: 'Gold', color: '#d9a12b' },
  { name: 'Rose', color: '#cf5378' },
];

function currentTheme(): GrokBotTheme {
  const base = dark ? darkTheme : lightTheme;
  return {
    ...base,
    bodyColor: bodyOverride ?? base.bodyColor,
    eyeColor: eyeOverride ?? base.eyeColor,
  };
}

function applyTheme(): void {
  document.body.classList.toggle('dark', dark);
  const theme = currentTheme();
  applyToAll({ theme });

  $<HTMLInputElement>('body-color').value = theme.bodyColor;
  $<HTMLInputElement>('eye-color').value = theme.eyeColor;
  // Inline on body so it beats both :root and body.dark, tinting the page UI too.
  document.body.style.setProperty('--accent', theme.bodyColor);
  for (const button of document.querySelectorAll<HTMLButtonElement>('.swatch')) {
    button.setAttribute('aria-pressed', String(button.dataset.color === bodyOverride));
  }

  const button = $<HTMLButtonElement>('theme');
  button.textContent = dark ? 'Light' : 'Dark';
  button.setAttribute('aria-pressed', String(dark));
}

$('theme').addEventListener('click', () => {
  dark = !dark;
  applyTheme();
  updateSnippet();
});

const swatchRow = $('swatches');
for (const { name, color } of SWATCHES) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'swatch';
  button.style.background = color;
  button.dataset.color = color;
  button.title = name;
  button.setAttribute('aria-label', `Body color: ${name}`);
  button.addEventListener('click', () => {
    bodyOverride = color;
    applyTheme();
    updateSnippet();
  });
  swatchRow.append(button);
}

$<HTMLInputElement>('body-color').addEventListener('input', (event) => {
  bodyOverride = (event.target as HTMLInputElement).value;
  applyTheme();
  updateSnippet();
});

$<HTMLInputElement>('eye-color').addEventListener('input', (event) => {
  eyeOverride = (event.target as HTMLInputElement).value;
  applyTheme();
  updateSnippet();
});

$('reset-colors').addEventListener('click', () => {
  bodyOverride = null;
  eyeOverride = null;
  applyTheme();
  updateSnippet();
});

// -------------------------------------------------------------------- snippet

function updateSnippet(): void {
  const o = hero.options;
  const lines = [
    "import { GrokBot } from 'grokbot-web';",
    '',
    'new GrokBot(canvas, {',
    `  state: '${o.state}',`,
    `  shape: '${o.shape}',`,
    o.expression === null ? '  expression: null,' : `  expression: ${o.expression},`,
    `  turn: ${o.turn},`,
    `  eyeScale: ${o.eyeScale},`,
    `  springFrequency: ${o.springFrequency},`,
    `  autoBlink: ${o.autoBlink},`,
    `  autoExpression: ${o.autoExpression},`,
    o.emphasis ? '  emphasis: true,' : null,
    o.flipX ? '  flipX: true,' : null,
    o.showGuides ? '  showGuides: true,' : null,
    bodyOverride || eyeOverride
      ? `  theme: { bodyColor: '${o.theme.bodyColor}', eyeColor: '${o.theme.eyeColor}' },`
      : dark
        ? '  theme: darkTheme,'
        : null,
    '});',
  ].filter((line): line is string => line !== null);
  $('snippet').textContent = lines.join('\n');
}

applyTheme();
updateSnippet();
