import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/index.ts', 'src/element.ts', 'src/react.tsx'],
  format: ['esm', 'cjs'],
  dts: true,
  clean: true,
  sourcemap: true,
  treeshake: true,
  target: 'es2022',
  external: ['react'],
});
