# Changelog

## 0.1.0

First release. A TypeScript / Canvas 2D port of
[nasawz/GrokBot](https://github.com/nasawz/GrokBot) `0.1.0`.

- All 25 expressions, 18 shapes and 39 states, with the upstream expression
  pools and blink / expression cadences intact.
- Gaze, head turn with spherical projection, spring expression morph, blink,
  `spin()` and `reset()`.
- Three entry points: the `GrokBot` engine, a `<grok-bot>` custom element and a
  `<GrokBotView>` React component.
- Web-only additions: device pixel ratio handling, `ResizeObserver` sizing,
  `prefers-reduced-motion` support, an injectable `random` source, and a first
  paint that does not wait for an animation frame.
